// Skin-specific Javascript code.

